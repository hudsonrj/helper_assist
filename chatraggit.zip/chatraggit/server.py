import os
import fitz  # PyMuPDF para manipulação de PDFs
import numpy as np
import pickle
from sentence_transformers import SentenceTransformer
from flask import Flask, request, jsonify, send_from_directory, render_template, redirect, url_for, session
from groq import Groq
from annoy import AnnoyIndex
import speech_recognition as sr
from gtts import gTTS
import tempfile
from flask_cors import CORS
from pydub import AudioSegment
import shutil
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
import pandas as pd
import docx
import csv
from bs4 import BeautifulSoup

## Desabilitar paralelismo de tokenizers para evitar avisos
os.environ["TOKENIZERS_PARALLELISM"] = "false"

## Carregar modelo de embeddings
modelo_embeddings = SentenceTransformer('all-MiniLM-L6-v2')

## Configurar cliente Groq
client = Groq(api_key="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")

## Inicializa o Flask
app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)  ## Habilitar CORS para permitir requisições do navegador
app.secret_key = 'supersecretkey'  ## Chave secreta para sessões

## Caminhos dos arquivos e diretórios
DIRETORIO_PDF = 'pdf_docs'
ARQUIVO_INDICE = 'annoy_index.ann'
ARQUIVO_NOMES_DOCUMENTOS = 'nomes_documentos.pkl'
DIRETORIO_AUDIO_RESP = 'audio_respostas'
NUM_FEATURES = 384  ## Número de dimensões do embedding
MAX_CONTEXT_SIZE = 3000  ## Limitar o tamanho do contexto para evitar ultrapassar limites da API

## Tipos de arquivos permitidos para indexação
TIPOS_PERMITIDOS = ['.pdf', '.docx', '.txt', '.html', '.csv', '.xlsx']

## Garantir que os diretórios existam
os.makedirs(DIRETORIO_PDF, exist_ok=True)
os.makedirs(DIRETORIO_AUDIO_RESP, exist_ok=True)

## Variáveis para manter o histórico da conversa
dialog_history = []
dialog_last_active = None

## Usuários iniciais (apenas para exemplo)
usuarios = {
    "hudson": {
        "password": generate_password_hash("hudson"),
        "role": "Administrador"
    }
}

## Função para verificar se o usuário está autenticado
def login_required(f):
    def wrap(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

## Função para verificar se o usuário é administrador
def admin_required(f):
    def wrap(*args, **kwargs):
        if 'username' not in session or usuarios.get(session['username'], {}).get('role') != 'Administrador':
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

## Função para carregar documentos e gerar embeddings
def carregar_documentos_e_gerar_embeddings(diretorio=DIRETORIO_PDF):
    documentos = {}
    embeddings = []
    nomes_arquivos = []

    for filename in os.listdir(diretorio):
        filepath = os.path.join(diretorio, filename)
        texto = ""

        if any(filename.endswith(ext) for ext in TIPOS_PERMITIDOS):
            if filename.endswith('.pdf'):
                with fitz.open(filepath) as pdf:
                    for pagina in pdf:
                        texto += pagina.get_text()
            elif filename.endswith('.docx'):
                doc = docx.Document(filepath)
                for para in doc.paragraphs:
                    texto += para.text + "\n"
            elif filename.endswith('.txt'):
                with open(filepath, 'r', encoding='utf-8') as file:
                    texto = file.read()
            elif filename.endswith('.csv'):
                with open(filepath, 'r', encoding='utf-8') as file:
                    reader = csv.reader(file)
                    for row in reader:
                        texto += ' '.join(row) + "\n"
            elif filename.endswith('.html'):
                with open(filepath, 'r', encoding='utf-8') as file:
                    soup = BeautifulSoup(file, 'html.parser')
                    texto = soup.get_text()
            elif filename.endswith('.xlsx'):
                df = pd.read_excel(filepath)
                texto = df.to_string()

            if texto:
                documentos[filename] = texto
                nomes_arquivos.append(filename)
                embedding = modelo_embeddings.encode(texto, convert_to_numpy=True)
                embeddings.append(embedding)

    matriz_embeddings = np.array(embeddings)
    return documentos, nomes_arquivos, matriz_embeddings

## Função para salvar o índice Annoy e os nomes dos documentos
def salvar_indice_e_nomes(indice, nomes_arquivos):
    indice.save(ARQUIVO_INDICE)
    with open(ARQUIVO_NOMES_DOCUMENTOS, 'wb') as f:
        pickle.dump(nomes_arquivos, f)

## Função para carregar o índice Annoy e os nomes dos documentos
def carregar_indice_e_nomes():
    if os.path.exists(ARQUIVO_INDICE) and os.path.exists(ARQUIVO_NOMES_DOCUMENTOS):
        indice = AnnoyIndex(NUM_FEATURES, 'angular')
        indice.load(ARQUIVO_INDICE)
        with open(ARQUIVO_NOMES_DOCUMENTOS, 'rb') as f:
            nomes_arquivos = pickle.load(f)
        return indice, nomes_arquivos
    return None, None

## Carregar ou criar índice Annoy e documentos
documentos_indexados, nomes_documentos, matriz_embeddings = carregar_documentos_e_gerar_embeddings()
indice_annoy, nomes_documentos_carregados = carregar_indice_e_nomes()

if not indice_annoy or not nomes_documentos_carregados:
    indice_annoy = AnnoyIndex(NUM_FEATURES, 'angular')
    for i, embedding in enumerate(matriz_embeddings):
        indice_annoy.add_item(i, embedding)
    indice_annoy.build(10)  ## Número de árvores para busca
    nomes_documentos = nomes_documentos
    salvar_indice_e_nomes(indice_annoy, nomes_documentos)
else:
    nomes_documentos = nomes_documentos_carregados

## Rota de login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = usuarios.get(username)
        if user and check_password_hash(user['password'], password):
            session['username'] = username
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error="Usuário ou senha incorretos.")

    return render_template('login.html')

## Rota de logout
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

## Rota para fornecer a lista de documentos (administrar os documentos)
@app.route('/admin-data', methods=['GET'])
@admin_required
def admin_data():
    try:
        documentos = os.listdir(DIRETORIO_PDF)  ## Obtém a lista de arquivos do diretório pdf_docs
        return jsonify({"documentos": documentos})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

## Rota para deletar um documento específico
@app.route('/delete-document', methods=['POST'])
@admin_required
def delete_document():
    data = request.get_json()
    filename = data.get('filename')
    filepath = os.path.join(DIRETORIO_PDF, filename)

    if os.path.exists(filepath):
        os.remove(filepath)
        return jsonify({"message": f"Documento '{filename}' removido com sucesso."})
    else:
        return jsonify({"message": f"Documento '{filename}' não encontrado."}), 404

## Rota para zerar documentos e índices
@app.route('/reset-indices', methods=['POST'])
@admin_required
def reset_indices():
    try:
        ## Remover todos os arquivos do diretório de documentos
        for filename in os.listdir(DIRETORIO_PDF):
            filepath = os.path.join(DIRETORIO_PDF, filename)
            os.remove(filepath)

        ## Remover arquivos de índice
        if os.path.exists(ARQUIVO_INDICE):
            os.remove(ARQUIVO_INDICE)
        if os.path.exists(ARQUIVO_NOMES_DOCUMENTOS):
            os.remove(ARQUIVO_NOMES_DOCUMENTOS)

        return jsonify({"message": "Todos os documentos e índices foram zerados com sucesso."})
    except Exception as e:
        return jsonify({"message": f"Erro ao zerar documentos e índices: {str(e)}"}), 500

## Rota para recriar índice com documentos existentes
@app.route('/recreate-index', methods=['POST'])
@admin_required
def recreate_index():
    try:
        global documentos_indexados, nomes_documentos, indice_annoy
        documentos_indexados, nomes_documentos, matriz_embeddings = carregar_documentos_e_gerar_embeddings()

        ## Criação de um novo índice Annoy de forma segura
        novo_indice_annoy = AnnoyIndex(NUM_FEATURES, 'angular')
        for i, embedding in enumerate(matriz_embeddings):
            novo_indice_annoy.add_item(i, embedding)
        novo_indice_annoy.build(10)

        ## Atualizar as variáveis globais
        indice_annoy = novo_indice_annoy
        salvar_indice_e_nomes(indice_annoy, nomes_documentos)

        return jsonify({"message": "Índice recriado com sucesso."}), 200
    except Exception as e:
        print(f"Erro ao recriar índice: {str(e)}")
        return jsonify({"message": f"Erro ao recriar índice: {str(e)}"}), 500


## Rota para enviar uma pergunta por texto
@app.route('/chat', methods=['POST'])
@login_required
def chat():
    print("Rota /chat acessada.")
    try:
        data = request.get_json()
        pergunta = data.get('pergunta', '')
        print(f"Pergunta recebida: {pergunta}")
        contexto = buscar_documentos_relevantes(pergunta)
        resposta = obter_resposta_do_chatgpt(pergunta, contexto)
        return jsonify({'resposta': resposta})
    except Exception as e:
        print(f"Erro no endpoint /chat: {str(e)}")
        return jsonify({'error': 'Erro ao processar a solicitação.'}), 500

## Função para buscar documentos relevantes usando Annoy
def buscar_documentos_relevantes(pergunta, limite=3):
    embedding_pergunta = modelo_embeddings.encode(pergunta, convert_to_numpy=True)
    indices = indice_annoy.get_nns_by_vector(embedding_pergunta, limite)
    documentos_relevantes = [documentos_indexados[nomes_documentos[i]] for i in indices if i < len(nomes_documentos)]
    contexto = " ".join(documentos_relevantes)
    ## Limitar o tamanho do contexto para evitar ultrapassar o limite de tokens da API
    if len(contexto) > MAX_CONTEXT_SIZE:
        contexto = contexto[:MAX_CONTEXT_SIZE]
    return contexto if contexto else "Nenhum documento relevante encontrado."

## Função para obter resposta do ChatGPT
def obter_resposta_do_chatgpt(pergunta, contexto):
    chat_completion = client.chat.completions.create(
        messages=[
            {
                "role": "system",
                "content": "Você vai atuar dentro do contexto fornecido, sendo agente ativo, pronto para ajudar no que for preciso. Responda educadamente e de forma objetiva, sempre em português do Brasil. De instrucoes corretas e sugestoes, quando necessario, tentando antever o desejo do outro. Responda de forma que esteja continuando uma conversa"
            },
            {
                "role": "user",
                "content": f"Contexto: {contexto}\n\nPergunta: {pergunta}\n\nResposta:"
            }
        ],
        model="llama3-8b-8192",
    )
    response = chat_completion.choices[0].message.content
    return response

## Rota para interação por áudio
@app.route('/audio-chat', methods=['POST'])
@login_required
def audio_chat():
    print("Rota /audio-chat acessada.")
    try:
        if 'audio' not in request.files:
            return jsonify({"message": "Nenhum arquivo de áudio foi enviado."}), 400

        audio_file = request.files['audio']
        if audio_file.filename == '':
            return jsonify({"message": "Nenhum arquivo de áudio foi selecionado."}), 400

        ## Salvar áudio temporariamente
        with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_audio:
            temp_audio_name = temp_audio.name
            audio_file.save(temp_audio_name)

        ## Converter áudio para formato compatível se necessário
        try:
            audio = AudioSegment.from_file(temp_audio_name)
            audio.export(temp_audio_name, format="wav")
        except Exception as e:
            return jsonify({"message": f"Erro ao converter o áudio: {str(e)}"}), 500

        ## Reconhecer fala usando SpeechRecognition
        recognizer = sr.Recognizer()
        with sr.AudioFile(temp_audio_name) as source:
            audio_data = recognizer.record(source)
        try:
            pergunta = recognizer.recognize_google(audio_data, language='pt-BR')
        except sr.UnknownValueError:
            return jsonify({"message": "Não foi possível entender o áudio."}), 400
        except sr.RequestError:
            return jsonify({"message": "Erro ao processar o áudio."}), 500

        ## Obter resposta do ChatGPT
        contexto = buscar_documentos_relevantes(pergunta)
        resposta = obter_resposta_do_chatgpt(pergunta, contexto)

        ## Converter resposta em áudio usando gTTS
        temp_audio_response_name = f"resposta_{os.path.basename(temp_audio_name)}.mp3"
        temp_audio_response_path = os.path.join(DIRETORIO_AUDIO_RESP, temp_audio_response_name)
        tts = gTTS(text=resposta, lang='pt')
        tts.save(temp_audio_response_path)

        print(f"Resposta de áudio salva em: {temp_audio_response_path}")

        ## Retornar resposta em texto e áudio como resposta
        return jsonify({'resposta_texto': resposta, 'resposta_audio_url': url_for('resposta_audio', filename=temp_audio_response_name)})
    except Exception as e:
        print(f"Erro no endpoint /audio-chat: {str(e)}")
        return jsonify({'error': 'Erro ao processar o áudio.'}), 500

## Rota para fornecer o áudio de resposta
@app.route('/audio/<path:filename>', methods=['GET'])
def resposta_audio(filename):
    return send_from_directory(DIRETORIO_AUDIO_RESP, filename)

## Rota para a página principal
@app.route('/')
@login_required
def index():
    return render_template('index.html')

## Rota para a página de administração
@app.route('/admin')
@admin_required
def admin():
    return render_template('admin.html')



@app.route('/upload', methods=['POST'])
@admin_required
def upload():
    try:
        # Verificar se algum arquivo foi enviado
        if 'file' not in request.files:
            return jsonify({"message": "Nenhum arquivo enviado."}), 400

        file = request.files['file']

        # Verificar se o arquivo tem um nome válido
        if file.filename == '':
            return jsonify({"message": "Nenhum arquivo selecionado."}), 400

        # Verificar se o tipo do arquivo é permitido
        if not any(file.filename.lower().endswith(ext) for ext in TIPOS_PERMITIDOS):
            return jsonify({"message": "Tipo de arquivo não suportado. Tipos permitidos: PDF, DOCX, XLSX, CSV, TXT, HTML"}), 400

        # Salvar o arquivo no diretório de documentos
        filepath = os.path.join(DIRETORIO_PDF, file.filename)
        file.save(filepath)

        # Atualizar os documentos e embeddings após o upload
        documentos_indexados, nomes_documentos, matriz_embeddings = carregar_documentos_e_gerar_embeddings()

        # Recriar o índice Annoy de forma segura
        novo_indice_annoy = AnnoyIndex(NUM_FEATURES, 'angular')
        for i, embedding in enumerate(matriz_embeddings):
            novo_indice_annoy.add_item(i, embedding)
        novo_indice_annoy.build(10)

        # Atualizar as variáveis globais e salvar o índice
        global indice_annoy
        indice_annoy = novo_indice_annoy
        salvar_indice_e_nomes(indice_annoy, nomes_documentos)

        return jsonify({"message": f"Arquivo '{file.filename}' enviado e indexado com sucesso."})

    except Exception as e:
        return jsonify({"message": f"Erro ao fazer upload do arquivo: {str(e)}"}), 500


# Rota para fornecer a lista de usuários
@app.route('/user-data', methods=['GET'])
@admin_required
def user_data():
   

    try:
        users_list = [{"username": user, "role": usuarios[user]["role"]} for user in usuarios]
        return jsonify({"usuarios": users_list})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Rota para adicionar um novo usuário
@app.route('/add-user', methods=['POST'])
@admin_required
def add_user():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    role = data.get('role', 'Usuario')

    if not username or not password:
        return jsonify({"message": "Nome de usuário e senha são obrigatórios."}), 400

    if username in usuarios:
        return jsonify({"message": "Usuário já existe."}), 400

    hashed_password = generate_password_hash(password)
    usuarios[username] = {"password": hashed_password, "role": role}

    return jsonify({"message": f"Usuário '{username}' adicionado com sucesso."})

# Rota para deletar um usuário específico
@app.route('/delete-user', methods=['POST'])
@admin_required
def delete_user():
    data = request.get_json()
    username = data.get('username')

    if username not in usuarios:
        return jsonify({"message": f"Usuário '{username}' não encontrado."}), 404

    if username == 'hudson':
        return jsonify({"message": "Não é possível excluir o usuário administrador principal."}), 400

    del usuarios[username]
    return jsonify({"message": f"Usuário '{username}' removido com sucesso."})


if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0',port=5000, debug=True)
    except Exception as e:
        print(f"Erro ao executar o servidor: {e}")
