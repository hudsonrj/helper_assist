import os
import fitz  # PyMuPDF para manipulação de PDFs
import numpy as np
import pickle
from sentence_transformers import SentenceTransformer
from flask import Flask, request, jsonify, send_from_directory
from groq import Groq
from annoy import AnnoyIndex

# Carregar modelo de embeddings
modelo_embeddings = SentenceTransformer('all-MiniLM-L6-v2')

# Configurar cliente Groq
client = Groq(api_key="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")

# Inicializa o Flask
app = Flask(__name__, static_folder='static')

# Caminhos dos arquivos
DIRETORIO_PDF = 'pdf_docs'
ARQUIVO_INDICE = 'annoy_index.ann'
ARQUIVO_NOMES_DOCUMENTOS = 'nomes_documentos.pkl'
NUM_FEATURES = 384  # Número de dimensões do embedding
MAX_CONTEXT_SIZE = 3000  # Limitar o tamanho do contexto para evitar ultrapassar limites da API

# Função para carregar documentos PDF e gerar embeddings
def carregar_documentos_pdf_e_gerar_embeddings(diretorio=DIRETORIO_PDF):
    documentos = {}
    embeddings = []
    nomes_arquivos = []

    for filename in os.listdir(diretorio):
        if filename.endswith('.pdf'):
            filepath = os.path.join(diretorio, filename)
            with fitz.open(filepath) as pdf:
                texto = ""
                for pagina in pdf:
                    texto += pagina.get_text()
            documentos[filename] = texto
            nomes_arquivos.append(filename)
            embedding = modelo_embeddings.encode(texto, convert_to_numpy=True)
            embeddings.append(embedding)

    matriz_embeddings = np.array(embeddings)
    return documentos, nomes_arquivos, matriz_embeddings

# Função para salvar o índice Annoy e os nomes dos documentos
def salvar_indice_e_nomes(indice, nomes_arquivos):
    indice.save(ARQUIVO_INDICE)
    with open(ARQUIVO_NOMES_DOCUMENTOS, 'wb') as f:
        pickle.dump(nomes_arquivos, f)

# Função para carregar o índice Annoy e os nomes dos documentos
def carregar_indice_e_nomes():
    if os.path.exists(ARQUIVO_INDICE) and os.path.exists(ARQUIVO_NOMES_DOCUMENTOS):
        indice = AnnoyIndex(NUM_FEATURES, 'angular')
        indice.load(ARQUIVO_INDICE)
        with open(ARQUIVO_NOMES_DOCUMENTOS, 'rb') as f:
            nomes_arquivos = pickle.load(f)
        return indice, nomes_arquivos
    return None, None

# Carregar ou criar índice Annoy e documentos
documentos_indexados, nomes_documentos, matriz_embeddings = carregar_documentos_pdf_e_gerar_embeddings()
indice_annoy, nomes_documentos_carregados = carregar_indice_e_nomes()

if not indice_annoy or not nomes_documentos_carregados:
    indice_annoy = AnnoyIndex(NUM_FEATURES, 'angular')
    for i, embedding in enumerate(matriz_embeddings):
        indice_annoy.add_item(i, embedding)
    indice_annoy.build(10)  # Número de árvores para busca
    nomes_documentos = nomes_documentos
    salvar_indice_e_nomes(indice_annoy, nomes_documentos)
else:
    nomes_documentos = nomes_documentos_carregados

def buscar_documentos_relevantes(pergunta, limite=3):
    embedding_pergunta = modelo_embeddings.encode(pergunta, convert_to_numpy=True)
    indices = indice_annoy.get_nns_by_vector(embedding_pergunta, limite)
    documentos_relevantes = [documentos_indexados[nomes_documentos[i]] for i in indices if i < len(nomes_documentos)]
    contexto = " ".join(documentos_relevantes)
    # Limitar o tamanho do contexto para evitar ultrapassar o limite de tokens da API
    if len(contexto) > MAX_CONTEXT_SIZE:
        contexto = contexto[:MAX_CONTEXT_SIZE]
    return contexto if contexto else "Nenhum documento relevante encontrado."

def obter_resposta_do_chatgpt(pergunta, contexto):
    chat_completion = client.chat.completions.create(
        messages=[
            {
                "role": "system",
                "content": "Você é um assistente pessoal, pronto para ajudar no que for preciso"
            },
            {
                "role": "user",
                "content": f"Contexto: {contexto}\n\nPergunta: {pergunta}\n\nResposta:"
            }
        ],
        model="llama3-8b-8192",
    )
    response = chat_completion.choices[0].message.content
    print(contexto)
    print(response)
    return response

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    pergunta = data.get('pergunta', '')
    contexto = buscar_documentos_relevantes(pergunta)
    resposta = obter_resposta_do_chatgpt(pergunta, contexto)
    return jsonify({'resposta': resposta})

@app.route('/upload', methods=['POST'])
def upload():
    if 'pdf' not in request.files:
        return jsonify({"message": "Nenhum arquivo foi enviado."}), 400

    file = request.files['pdf']
    if file.filename == '':
        return jsonify({"message": "Nenhum arquivo foi selecionado."}), 400

    filepath = os.path.join(DIRETORIO_PDF, file.filename)
    file.save(filepath)

    global documentos_indexados, nomes_documentos, indice_annoy
    documentos_indexados, nomes_documentos, matriz_embeddings = carregar_documentos_pdf_e_gerar_embeddings()

    # Criação de um novo índice Annoy de forma segura
    novo_indice_annoy = AnnoyIndex(NUM_FEATURES, 'angular')
    for i, embedding in enumerate(matriz_embeddings):
        novo_indice_annoy.add_item(i, embedding)
    novo_indice_annoy.build(10)

    # Atualizar as variáveis globais
    indice_annoy = novo_indice_annoy
    salvar_indice_e_nomes(indice_annoy, nomes_documentos)

    return jsonify({"message": "Arquivo carregado e indexado com sucesso."})

@app.route('/')
def index():
    return send_from_directory('', 'index.html')

if __name__ == '__main__':
    try:
        app.run(port=5000, debug=True)
    except Exception as e:
        print(f"Erro ao executar o servidor: {e}")
