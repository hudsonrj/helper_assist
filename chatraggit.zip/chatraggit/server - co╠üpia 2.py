from openai import OpenAI

#client = OpenAI(api_key="sk-hcs-account-y3YVsqfqyNSBM9rRl72yT3BlbkFJB4PKHd3DxOMe1grQS1cp")
#client = openai.OpenAI(base_url="https://api.groq.com/openai/v1",api_key="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")
import fitz  # PyMuPDF para manipulação de PDFs
from groq import Groq
import os
from flask import Flask, request, jsonify, send_from_directory, render_template
client = Groq(
    # This is the default and can be omitted
    api_key="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")
# Configuração da API OpenAI

app = Flask(__name__, static_folder='static')

# Função para carregar documentos em PDF
def carregar_documentos_pdf():
    documentos = {}
    for filename in os.listdir('pdf_docs'):
        if filename.endswith('.pdf'):
            filepath = os.path.join('pdf_docs', filename)
            with fitz.open(filepath) as pdf:
                texto = ""
                for pagina in pdf:
                    texto += pagina.get_text()
            documentos[filename] = texto
    return documentos

# Inicializa documentos globais para indexação
documentos_indexados = carregar_documentos_pdf()

# Função para selecionar documentos relevantes
def selecionar_documentos_relevantes(pergunta, documentos, limite=500):
    documentos_relevantes = []
    for nome, conteudo in documentos.items():
        if pergunta.lower() in conteudo.lower():
            documentos_relevantes.append(conteudo)
    contexto = " ".join(documentos_relevantes)[:limite]
    return contexto if contexto else "Nenhum documento relevante encontrado."

# Função para obter resposta do ChatGPT
def obter_resposta_do_chatgpt(pergunta, contexto):
    print(f"Contexto: {contexto}\n\nPergunta: {pergunta}\n\nResposta:")
    chat_completion = client.chat.completions.create(
        messages=[
            {
                "role": "system",
                "content": "Você é um assistente pessoal, pronto para ajudar no que for preciso"
            },
            {
                "role": "user",
                "content": f"Contexto: {contexto}\n\nPergunta: {pergunta}\n\nResposta:",
            }
        ],
        model="llama3-8b-8192",
    )


    #prompt = [{
    #        'role': 'user',
    #        'content': f"Contexto: {contexto}\n\nPergunta: {pergunta}\n\nResposta:"
    #}]

    response = chat_completion.choices[0].message.content
    print(response)
    
    return response

# Rota para servir o index.html
@app.route('/')
def index():
    return send_from_directory('', 'index.html')

# Rota para interação com ChatGPT
@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    pergunta = data.get('pergunta', '')

    # Seleciona documentos relevantes para o contexto
    contexto = selecionar_documentos_relevantes(pergunta, documentos_indexados)

    # Obtenha resposta do ChatGPT usando o contexto relevante
    resposta = obter_resposta_do_chatgpt(pergunta, contexto)

    return jsonify({'resposta': resposta})

# Rota para upload de PDF
@app.route('/upload', methods=['POST'])
def upload():
    if 'pdf' not in request.files:
        return jsonify({"message": "Nenhum arquivo foi enviado."}), 400

    file = request.files['pdf']
    if file.filename == '':
        return jsonify({"message": "Nenhum arquivo foi selecionado."}), 400

    # Salva o PDF em pdf_docs
    filepath = os.path.join('pdf_docs', file.filename)
    file.save(filepath)

    # Re-indexa os documentos
    global documentos_indexados
    documentos_indexados = carregar_documentos_pdf()

    return jsonify({"message": "Arquivo carregado e indexado com sucesso."})

if __name__ == '__main__':
    app.run(port=5000)
