$(document).ready(function () {
    // Carregar lista de usuários ao acessar a página de administração
    $.get('/user-data', function (data) {
        if (data.usuarios) {
            let userTable = $('#user-table');
            userTable.empty();  // Limpar a tabela antes de preenchê-la
            data.usuarios.forEach(function (user) {
                userTable.append(`<tr>
                    <td>${user.username}</td>
                    <td>${user.role}</td>
                    <td><button class="btn btn-danger delete-user" data-username="${user.username}">Excluir</button></td>
                </tr>`);
            });
        }
    }).fail(function () {
        alert('Erro ao carregar lista de usuários.');
    });

    // Adicionar novo usuário
    $('#add-user').click(function () {
        let username = $('#username').val();
        let password = $('#password').val();
        let role = $('#role').val();

        $.ajax({
            url: '/add-user',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ username: username, password: password, role: role }),
            success: function (response) {
                alert(response.message);
                location.reload();  // Recarregar a página para atualizar a lista de usuários
            },
            error: function (response) {
                alert(response.responseJSON.message);
            }
        });
    });

    // Deletar usuário
    $(document).on('click', '.delete-user', function () {
        let username = $(this).data('username');

        $.ajax({
            url: '/delete-user',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ username: username }),
            success: function (response) {
                alert(response.message);
                location.reload();  // Recarregar a página para atualizar a lista de usuários
            },
            error: function (response) {
                alert(response.responseJSON.message);
            }
        });
    });

    // Carregar lista de documentos ao acessar a página de administração
    $.get('/admin-data', function (data) {
        if (data.documentos) {
            let docTable = $('#document-table');
            docTable.empty();  // Limpar a tabela antes de preenchê-la
            data.documentos.forEach(function (doc) {
                docTable.append(`<tr>
                    <td>${doc}</td>
                    <td><button class="btn btn-danger delete-document" data-filename="${doc}">Excluir</button></td>
                </tr>`);
            });
        }
    }).fail(function () {
        alert('Erro ao carregar lista de documentos.');
    });

    // Deletar documento
    $(document).on('click', '.delete-document', function () {
        let filename = $(this).data('filename');

        $.ajax({
            url: '/delete-document',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ filename: filename }),
            success: function (response) {
                alert(response.message);
                location.reload();  // Recarregar a página para atualizar a lista de documentos
            },
            error: function (response) {
                alert(response.responseJSON.message);
            }
        });
    });

    // Recriar índice
    $('#recreate-index').click(function () {
        $.ajax({
            url: '/recreate-index',
            type: 'POST',
            success: function (response) {
                alert(response.message);
                location.reload();  // Recarregar a página para atualizar a lista de documentos
            },
            error: function (response) {
                alert(response.responseJSON.message);
            }
        });
    });

    // Zerar documentos e índices
    $('#reset-indices').click(function () {
        $.ajax({
            url: '/reset-indices',
            type: 'POST',
            success: function (response) {
                alert(response.message);
                location.reload();  // Recarregar a página para atualizar a lista de documentos
            },
            error: function (response) {
                alert(response.responseJSON.message);
            }
        });
    });
});
