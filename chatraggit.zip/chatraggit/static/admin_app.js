$(document).ready(function () {
    // Função para listar documentos na página de administração
    function listarDocumentos() {
        $.ajax({
            url: '/admin-data',
            type: 'GET',
            success: function (response) {
                let documentosHtml = '';
                if (response.documentos && response.documentos.length > 0) {
                    response.documentos.forEach(function (doc) {
                        documentosHtml += `
                            <div class="document-item mb-2">
                                <span>${doc}</span>
                                <button class="btn btn-danger btn-sm float-end delete-document" data-filename="${doc}"><i class="fas fa-trash-alt"></i> Remover</button>
                            </div>
                        `;
                    });
                } else {
                    documentosHtml = '<p>Nenhum documento encontrado.</p>';
                }
                $('#document-list').html(documentosHtml);
            },
            error: function () {
                alert('Erro ao carregar a lista de documentos.');
            }
        });
    }

    // Função para listar usuários na página de administração
    function listarUsuarios() {
        $.ajax({
            url: '/user-data',
            type: 'GET',
            success: function (response) {
                let usuariosHtml = '';
                if (response.usuarios && response.usuarios.length > 0) {
                    response.usuarios.forEach(function (user) {
                        usuariosHtml += `
                            <div class="user-item mb-2">
                                <span>${user.username} (${user.role})</span>
                                <button class="btn btn-danger btn-sm float-end delete-user" data-username="${user.username}"><i class="fas fa-trash-alt"></i> Remover</button>
                            </div>
                        `;
                    });
                } else {
                    usuariosHtml = '<p>Nenhum usuário encontrado.</p>';
                }
                $('#user-list').html(usuariosHtml);
            },
            error: function () {
                alert('Erro ao carregar a lista de usuários.');
            }
        });
    }

    // Chama a função para listar documentos e usuários ao carregar a página
    listarDocumentos();
    listarUsuarios();

    // Remover documento
    $(document).on('click', '.delete-document', function () {
        const filename = $(this).data('filename');
        $.ajax({
            url: '/delete-document',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ filename: filename }),
            success: function (response) {
                alert(response.message);
                listarDocumentos();
            },
            error: function () {
                alert('Erro ao remover o documento.');
            }
        });
    });

    // Remover usuário
    $(document).on('click', '.delete-user', function () {
        const username = $(this).data('username');
        $.ajax({
            url: '/delete-user',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ username: username }),
            success: function (response) {
                alert(response.message);
                listarUsuarios();
            },
            error: function () {
                alert('Erro ao remover o usuário.');
            }
        });
    });

    // Recriar índice de documentos
    $('#reindex-documents').click(function () {
        $('#progress-bar').show();
        const progressBar = $('#progress-bar .progress-bar');
        progressBar.css('width', '0%').attr('aria-valuenow', 0);

        $.ajax({
            url: '/recreate-index',
            type: 'POST',
            beforeSend: function () {
                $('#progress-bar').show();
                progressBar.addClass('progress-bar-animated');
                simulateIndexingAnimation();
            },
            success: function (response) {
                alert(response.message);
                $('#progress-bar').hide();
                listarDocumentos();
            },
            error: function (xhr) {
                alert(`Erro ao recriar o índice: ${xhr.responseText}`);
                $('#progress-bar').hide();
            }
        });
    });

    // Simulação da animação da barra de progresso
    function simulateIndexingAnimation() {
        const progressBar = $('#progress-bar .progress-bar');
        let progress = 0;

        const interval = setInterval(function () {
            if (progress < 100) {
                progress += 10; // Incrementa 10% a cada ciclo
                progressBar.css('width', progress + '%').attr('aria-valuenow', progress);
            } else {
                clearInterval(interval);
            }
        }, 500); // Atualiza a cada 500ms
    }

    // Zerar documentos e índices
    $('#reset-documents').click(function () {
        $.ajax({
            url: '/reset-indices',
            type: 'POST',
            success: function (response) {
                alert(response.message);
                listarDocumentos();
            },
            error: function () {
                alert('Erro ao zerar os documentos e índices.');
            }
        });
    });

    // Carregar novo documento
    $('#upload-document').click(function () {
        const documentFile = $('#document-upload')[0].files[0];
        if (!documentFile) {
            alert('Por favor, selecione um arquivo.');
            return;
        }

        const formData = new FormData();
        formData.append('file', documentFile);  // Certifique-se de que o backend está esperando 'file'

        $('#progress-bar').show();
        const progressBar = $('#progress-bar .progress-bar');
        progressBar.css('width', '0%').attr('aria-valuenow', 0);

        $.ajax({
            url: '/upload',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function () {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function (evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = (evt.loaded / evt.total) * 100;
                        progressBar.css('width', percentComplete + '%').attr('aria-valuenow', percentComplete);
                    }
                }, false);
                return xhr;
            },
            success: function (response) {
                alert(response.message);
                $('#progress-bar').hide();
                listarDocumentos();
            },
            error: function (xhr) {
                alert(`Erro ao fazer upload do documento: ${xhr.responseText}`);
                $('#progress-bar').hide();
            }
        });
    });

    // Adicionar novo usuário
    $('#add-user').click(function () {
        const username = prompt('Digite o nome do novo usuário:');
        const password = prompt('Digite a senha do novo usuário:');
        const role = confirm('O usuário é um administrador?') ? 'Administrador' : 'Usuário';

        if (username && password) {
            $.ajax({
                url: '/add-user',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ username: username, password: password, role: role }),
                success: function (response) {
                    alert(response.message);
                    listarUsuarios();
                },
                error: function () {
                    alert('Erro ao adicionar o usuário.');
                }
            });
        }
    });

    // Voltar para a página principal
    $('#back-main').click(function () {
        window.location.href = '/';
    });
});
